from .models import UserProfile, DietPlan, Meal, MealItem

# Simple deterministic diet engine

RECIPE_CATALOG = {
    'Oatmeal': {'cal': 300, 'items': [('Oats', '1 cup'), ('Milk', '1 cup')]},
    'Dal Khichdi': {'cal': 500, 'items': [('Rice', '1 cup'), ('Lentils', '1/2 cup')]},
    'Steamed Veg': {'cal': 200, 'items': [('Mixed Veggies', '1 plate')]},
    'Curd Rice': {'cal': 350, 'items': [('Rice', '1 cup'), ('Curd', '1/2 cup')]},
    'Fruit Salad': {'cal': 150, 'items': [('Assorted Fruits', '1 bowl')]},
}

ACTIVITY_FACTOR = {
    'sedentary': 1.2,
    'light': 1.375,
    'moderate': 1.55,
    'active': 1.725,
    'very-active': 1.9,
}


def calculate_bmr(profile: UserProfile) -> float:
    if profile.gender == 'male':
        bmr = 10 * profile.weight_kg + 6.25 * profile.height_cm - 5 * profile.age + 5
    else:
        bmr = 10 * profile.weight_kg + 6.25 * profile.height_cm - 5 * profile.age - 161
    return bmr


def estimate_daily_calories(profile: UserProfile) -> int:
    bmr = calculate_bmr(profile)
    activity = ACTIVITY_FACTOR.get(profile.activity_level.value, 1.2)
    return int(bmr * activity)


def pick_meals_for_calories(calories: int, exclusions: list) -> list:
    # naive: pick meals until reaching calories target using catalog
    selected = []
    total = 0
    for name, meta in RECIPE_CATALOG.items():
        if any(ex.lower() in name.lower() for ex in exclusions):
            continue
        selected.append((name, meta))
        total += meta['cal']
        if total >= calories:
            break
    # convert to Meal objects
    meals = []
    times = ['breakfast', 'lunch', 'dinner', 'snack']
    for i, (name, meta) in enumerate(selected):
        items = [MealItem(food=f, portion=p) for f, p in meta['items']]
        meals.append(Meal(name=name, time_of_day=times[i % len(times)], items=items))
    return meals


def generate_plan(profile: UserProfile) -> DietPlan:
    calories = estimate_daily_calories(profile)
    meals = pick_meals_for_calories(int(calories * 0.95), profile.exclusions or [])
    plan = DietPlan(user_id=profile.id, target_calories=calories, meals=meals, filters_applied={'exclusions': profile.exclusions})
    return plan
