import { Router } from 'express';
import {
	getDietCharts,
	getDiet,
	createDiet,
	updateDiet,
	deleteDiet
} from '../controllers/dietController';
import { authenticateJWT } from '../middleware/auth';

const router = Router();

// Public GET for now (auth optional during development)
router.get('/', getDietCharts);
router.get('/:id', getDiet);
router.post('/', authenticateJWT, createDiet);
router.put('/:id', authenticateJWT, updateDiet);
router.delete('/:id', authenticateJWT, deleteDiet);

export default router;