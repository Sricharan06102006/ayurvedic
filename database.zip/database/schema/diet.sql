CREATE TABLE patients (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  age INT,
  gender VARCHAR(10),
  bowel_movements VARCHAR(50),
  water_intake VARCHAR(50)
);

CREATE TABLE food_items (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  calories INT,
  macros JSONB,
  micros JSONB,
  ayurvedic_properties JSONB
);

CREATE TABLE diet_charts (
  id SERIAL PRIMARY KEY,
  patient_id INT REFERENCES patients(id),
  meals JSONB,
  nutritional_summary JSONB
);