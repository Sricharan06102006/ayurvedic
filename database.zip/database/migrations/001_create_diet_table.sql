CREATE TABLE diets (
    id SERIAL PRIMARY KEY,
    patient_id INT NOT NULL,
    meals JSONB NOT NULL,
    nutritional_summary TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);