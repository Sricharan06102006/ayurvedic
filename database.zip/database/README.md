# Database Setup for Ayurvedic Diet Management Software

This directory contains the necessary files for setting up and managing the database for the Ayurvedic Diet Management Software.

## Schema

- **schema/diet.sql**: This file contains the SQL schema for the diet management database, defining tables for patients, diets, and recipes.

## Migrations

- **migrations/001_create_diet_table.sql**: This file contains the SQL migration script to create the initial diet table in the PostgreSQL database.

## Instructions

1. **Database Connection**: Ensure that you have a PostgreSQL database set up and running. Update your backend configuration to connect to this database.

2. **Running Migrations**: Use a migration tool or run the SQL scripts manually to set up the database schema. The migration script should be executed in the order they are created.

3. **Seeding Data**: Consider creating additional scripts to seed your database with initial data for testing purposes.

4. **Backup**: Regularly back up your database to prevent data loss.

For further details on the database schema and migrations, refer to the respective SQL files in the `schema` and `migrations` directories.