# Frontend (Flask)

This is a simple Flask frontend for the Ayurvedic Diet Management project. It is intentionally lightweight and fetches diet plans from a backend API.

Run (Windows PowerShell):

```powershell
cd frontend_python
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

By default the frontend will call `http://localhost:4000` as the backend. To change, set the `API_BASE` environment variable before starting the app.
