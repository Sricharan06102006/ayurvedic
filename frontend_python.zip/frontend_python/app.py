from flask import Flask, render_template, jsonify, request
import os

app = Flask(__name__, template_folder='templates', static_folder='static')

# Configure this to point to your backend (FastAPI) server
API_BASE = os.environ.get('API_BASE', 'http://localhost:4000')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/diet-plans')
def diet_plans():
    # The page will fetch diet plans client-side using the configured API_BASE
    return render_template('diet_plans.html', api_base=API_BASE)

@app.route('/recipes')
def recipes():
    return render_template('recipes.html')

@app.route('/about')
def about():
    return render_template('about.html')

# Simple health endpoint for the frontend service
@app.route('/health')
def health():
    return jsonify({'status': 'ok', 'service': 'frontend'})

if __name__ == '__main__':
    # Development server
    app.run(host='0.0.0.0', port=5000, debug=True)
