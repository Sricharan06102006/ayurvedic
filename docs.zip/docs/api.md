# API Documentation for Ayurvedic Diet Management Software

## Overview
This document provides details about the API endpoints available in the Ayurvedic Diet Management Software. Each endpoint includes information about the request method, URL, request parameters, and response format.

## Base URL
The base URL for all API endpoints is:
```
http://localhost:3000/api
```

## Endpoints

### 1. Create Diet Plan
- **Method:** POST
- **URL:** `/diets`
- **Request Body:**
  ```json
  {
    "patientId": "string",
    "meals": [
      {
        "mealType": "string",
        "foodItems": ["string"]
      }
    ],
    "nutritionalSummary": {
      "calories": "number",
      "proteins": "number",
      "carbohydrates": "number",
      "fats": "number"
    }
  }
  ```
- **Response:**
  - **Status 201:** Created
  ```json
  {
    "id": "string",
    "message": "Diet plan created successfully."
  }
  ```

### 2. Get Diet Plan
- **Method:** GET
- **URL:** `/diets/:id`
- **URL Parameters:**
  - `id`: The ID of the diet plan to retrieve.
- **Response:**
  - **Status 200:** OK
  ```json
  {
    "id": "string",
    "patientId": "string",
    "meals": [
      {
        "mealType": "string",
        "foodItems": ["string"]
      }
    ],
    "nutritionalSummary": {
      "calories": "number",
      "proteins": "number",
      "carbohydrates": "number",
      "fats": "number"
    }
  }
  ```

### 3. Update Diet Plan
- **Method:** PUT
- **URL:** `/diets/:id`
- **URL Parameters:**
  - `id`: The ID of the diet plan to update.
- **Request Body:**
  ```json
  {
    "meals": [
      {
        "mealType": "string",
        "foodItems": ["string"]
      }
    ],
    "nutritionalSummary": {
      "calories": "number",
      "proteins": "number",
      "carbohydrates": "number",
      "fats": "number"
    }
  }
  ```
- **Response:**
  - **Status 200:** OK
  ```json
  {
    "message": "Diet plan updated successfully."
  }
  ```

### 4. Delete Diet Plan
- **Method:** DELETE
- **URL:** `/diets/:id`
- **URL Parameters:**
  - `id`: The ID of the diet plan to delete.
- **Response:**
  - **Status 204:** No Content

## Error Handling
All endpoints will return appropriate HTTP status codes and error messages in the following format:
```json
{
  "error": "Error message describing the issue."
}
```

## Example Usage
### Create Diet Plan Example
```bash
curl -X POST http://localhost:3000/api/diets -H "Content-Type: application/json" -d '{
  "patientId": "12345",
  "meals": [{"mealType": "Breakfast", "foodItems": ["Oatmeal", "Banana"]}],
  "nutritionalSummary": {"calories": 300, "proteins": 10, "carbohydrates": 50, "fats": 5}
}'
```

### Get Diet Plan Example
```bash
curl -X GET http://localhost:3000/api/diets/12345
```

## Conclusion
This API documentation provides a comprehensive overview of the endpoints available for managing diet plans in the Ayurvedic Diet Management Software. For further assistance, please refer to the general project documentation.